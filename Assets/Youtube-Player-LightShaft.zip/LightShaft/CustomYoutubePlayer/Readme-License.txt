Custom player made by JannikLassahn
https://github.com/JannikLassahn/unity-videoplayer-helper

Customized version by lightshaft.
If you want a updated version of this player only (without youtube support) check the https://github.com/JannikLassahn/unity-videoplayer-helper page.