Hi if you have any doubt or issue you can contact us at https://seedsofnature.net/utube-tickets/

The usage of the plugin is simple, you can use a prefab and modify to what you need.

EAC Panoramic skybox thanks to Hakanai: https://github.com/hakanai/EACSkyboxShader

For webgl take a look at the folder 'WebglSetup' if you want to host your webgl player system. (I 100% recommend to use your own).
