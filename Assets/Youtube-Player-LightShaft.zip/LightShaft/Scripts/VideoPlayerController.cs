﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VideoPlayerController : MonoBehaviour
{
    /*Some Users requested this feature, so now it goes:
    *Now you have the controls separated from the main code.
    */

}
