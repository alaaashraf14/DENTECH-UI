﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DemoCustomPlayerScript : MonoBehaviour
{
    //This script CanBe a avpro, easy movie texture, UMP... script;
    public void Play(string path)
    {
        Debug.Log("DEMO: START PLAYING YOUTUBE URL ON A CUSTOM PLAYER");
    }
}
